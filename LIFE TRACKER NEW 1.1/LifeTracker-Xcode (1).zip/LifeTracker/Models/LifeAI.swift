import Foundation
import SwiftUI
import SwiftData

// MARK: - Life AI
//
// The assistant that lives in the floating panel. It talks to Google's Gemini
// API directly from the device — there is no server in between, and nothing
// about you is stored anywhere but this Mac / iPad.
//
// What it can see is decided in one place, `AIContextBuilder` (AIContext.swift):
// habits, schedule, timetable, subjects and their material, calendar marks,
// progress and GitHub. **Journal is never included.** If you add a new page to
// the app, it stays invisible to Life AI until you add it there on purpose.

// MARK: Models
//
// Google renames and retires Gemini models regularly, so nothing here is
// hard-coded as the truth. The app asks your key which models it can actually
// use and offers those; the list below is only a starting guess for the very
// first message, before that answer comes back.

struct GeminiModelInfo: Identifiable, Hashable, Codable {
    /// Bare id, e.g. "gemini-2.5-flash" (the API returns "models/…").
    let name: String
    let displayName: String
    let detail: String

    var id: String { name }

    /// "Gemini 2.5 Flash" → "2.5 Flash", so the menu stays narrow.
    var shortTitle: String {
        let title = displayName.isEmpty ? name : displayName
        return title
            .replacingOccurrences(of: "Gemini ", with: "")
            .replacingOccurrences(of: "gemini-", with: "")
    }
}

// MARK: Stored chat

@Model
final class AIConversation {
    @Attribute(.unique) var id: UUID
    var title: String
    var createdAt: Date
    var updatedAt: Date

    @Relationship(deleteRule: .cascade, inverse: \AIMessage.conversation)
    var messages: [AIMessage] = []

    init(title: String = "New chat") {
        self.id = UUID()
        self.title = title
        self.createdAt = .now
        self.updatedAt = .now
    }

    var ordered: [AIMessage] { messages.sorted { $0.createdAt < $1.createdAt } }
}

@Model
final class AIMessage {
    @Attribute(.unique) var id: UUID
    /// "user" or "model".
    var roleRaw: String
    var text: String
    var createdAt: Date
    /// Names of the material chunks that were quoted into this answer.
    var sources: [String]
    /// Short descriptions of anything the assistant changed in the app.
    var actions: [String]
    /// File names attached to this message, for the chips above it.
    /// Defaulted so a store written by an earlier build migrates cleanly.
    var attachmentNames: [String] = []
    var conversation: AIConversation?

    init(role: String, text: String, sources: [String] = [],
         actions: [String] = [], attachmentNames: [String] = []) {
        self.id = UUID()
        self.roleRaw = role
        self.text = text
        self.createdAt = .now
        self.sources = sources
        self.actions = actions
        self.attachmentNames = attachmentNames
    }

    var isUser: Bool { roleRaw == "user" }
}

// MARK: - Wire format

struct GeminiRequest: Encodable {
    struct InlineData: Encodable {
        let mimeType: String
        /// Base64 of the file's bytes.
        let data: String
    }
    struct Part: Encodable {
        var text: String?
        var inlineData: InlineData?
        var functionResponse: FunctionResponse?
        var functionCall: FunctionCall?

        static func text(_ value: String) -> Part { Part(text: value) }
        static func file(mime: String, bytes: Data) -> Part {
            Part(inlineData: InlineData(mimeType: mime, data: bytes.base64EncodedString()))
        }
    }
    struct FunctionResponse: Encodable {
        let name: String
        let response: [String: String]
    }
    struct FunctionCall: Encodable {
        let name: String
        let args: [String: String]
    }
    struct Content: Encodable {
        let role: String
        let parts: [Part]
    }
    struct SystemInstruction: Encodable {
        let parts: [Part]
    }
    struct GenerationConfig: Encodable {
        let temperature: Double
        let maxOutputTokens: Int
    }
    struct Tool: Encodable {
        let functionDeclarations: [FunctionDeclaration]
    }
    struct FunctionDeclaration: Encodable {
        let name: String
        let description: String
        let parameters: Schema
    }
    struct Schema: Encodable {
        let type: String
        var description: String?
        var properties: [String: Schema]?
        var required: [String]?

        static func object(_ properties: [String: Schema], required: [String] = []) -> Schema {
            Schema(type: "OBJECT", properties: properties, required: required)
        }
        static func string(_ description: String) -> Schema {
            Schema(type: "STRING", description: description)
        }
        static func bool(_ description: String) -> Schema {
            Schema(type: "BOOLEAN", description: description)
        }
    }

    let contents: [Content]
    var systemInstruction: SystemInstruction?
    var tools: [Tool]?
    var generationConfig: GenerationConfig?
}

/// One streamed chunk. Gemini sends a full `GenerateContentResponse` per SSE
/// event, so every field is optional.
private struct GeminiChunk: Decodable {
    struct Part: Decodable {
        let text: String?
        let functionCall: Call?
    }
    struct Call: Decodable {
        let name: String
        let args: [String: AnyCodable]?
    }
    struct Content: Decodable {
        let parts: [Part]?
    }
    struct Candidate: Decodable {
        let content: Content?
        let finishReason: String?
    }
    struct ErrorBody: Decodable {
        let message: String?
        let status: String?
    }
    let candidates: [Candidate]?
    let error: ErrorBody?
}

/// Minimal "any JSON value" so function-call arguments survive decoding
/// whatever type the model picked (string, number, bool).
struct AnyCodable: Decodable {
    let stringValue: String

    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if let s = try? c.decode(String.self) { stringValue = s }
        else if let b = try? c.decode(Bool.self) { stringValue = b ? "true" : "false" }
        else if let i = try? c.decode(Int.self) { stringValue = String(i) }
        else if let d = try? c.decode(Double.self) { stringValue = String(d) }
        else { stringValue = "" }
    }
}

/// Error the client raises when the chosen model doesn't exist for this key,
/// so the caller knows to re-discover and retry rather than give up.
private struct UnknownModelError: Error {
    let message: String
}

// MARK: - Actions the assistant may take

/// One thing Life AI asked the app to do. The panel executes these on the main
/// actor with the live `ModelContext` and hands back a one-line result, which
/// goes to the model so it can tell you what happened in its own words.
struct AIAction {
    let name: String
    let args: [String: String]
}

// MARK: - The client

final class LifeAI: ObservableObject {
    static let shared = LifeAI()

    /// Your own key, so this build works the moment it launches.
    ///
    /// ⚠️ This is a real secret sitting in source. Anyone who gets a copy of
    /// the app — including anyone who downloads a release you publish from the
    /// GitHub page — can read it out. If this project's repo is ever public,
    /// clear this string, rotate the key at aistudio.google.com, and type the
    /// new one into Settings → Life AI instead (it lives in the Keychain there,
    /// and never leaves the device).
    static let bundledAPIKey = "AQ.Ab8RN6JvJpveSGpd-PUfbvltDeV_-WGox8HX28clF6Fq0UBNjQ"

    private static let keychainKey = "gemini.apiKey"
    private static let modelKey = "lifeAI.modelName"

    @Published private(set) var isStreaming = false
    @Published var lastError: String?
    /// Text produced so far for the answer being streamed.
    @Published var partial: String = ""
    /// What it is doing right now ("Reading your material…", "Adding a reminder…").
    @Published var activity: String = ""

    /// Models this key can actually use, straight from Google.
    @Published private(set) var availableModels: [GeminiModelInfo] = []
    @Published private(set) var isLoadingModels = false
    /// The model in use. Changing it is remembered between launches.
    @Published var modelName: String {
        didSet { UserDefaults.standard.set(modelName, forKey: Self.modelKey) }
    }

    /// The turn in flight. The panel assigns it so Stop can actually stop it.
    var task: Task<Void, Never>?

    /// Only used before the first successful model listing. Google retires and
    /// renames these, which is exactly why the app asks rather than assumes.
    private static let startingGuesses = [
        "gemini-flash-latest",
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-flash-lite-latest",
        "gemini-pro-latest"
    ]

    var currentModel: GeminiModelInfo? {
        availableModels.first { $0.name == modelName }
    }

    private init() {
        let saved = UserDefaults.standard.string(forKey: Self.modelKey) ?? ""
        modelName = saved.isEmpty ? Self.startingGuesses[0] : saved
        // First launch: seed the Keychain from the bundled key so there is
        // nothing to set up. Anything you type in Settings wins from then on.
        if (Keychain.get(Self.keychainKey) ?? "").isEmpty, !Self.bundledAPIKey.isEmpty {
            Keychain.set(Self.bundledAPIKey, for: Self.keychainKey)
        }
    }

    // MARK: Key

    var apiKey: String {
        (Keychain.get(Self.keychainKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var isConfigured: Bool { !apiKey.isEmpty }

    /// Masked for display — never shows the whole thing.
    var maskedKey: String {
        let key = apiKey
        guard key.count > 10 else { return key.isEmpty ? "" : "••••••" }
        return key.prefix(6) + "…" + key.suffix(4)
    }

    @MainActor
    func setKey(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        Keychain.set(trimmed.isEmpty ? nil : trimmed, for: Self.keychainKey)
        availableModels = []
        objectWillChange.send()
    }

    /// Cheap round-trip that proves the key works. Doubles as model discovery.
    @MainActor
    func verifyKey() async -> String? {
        guard isConfigured else { return "No key saved yet." }
        do {
            let models = try await fetchModels()
            adopt(models)
            return models.isEmpty ? "The key works, but it can't use any Gemini model that generates text." : nil
        } catch {
            return error.localizedDescription
        }
    }

    // MARK: Model discovery
    //
    // The 404 people hit — "model gemini-x.y-flash is not found for API version
    // v1beta" — happens because model names come and go. So rather than shipping
    // a guess, the app asks the key what it can use and offers exactly that.

    /// Asks Google which models this key may use. Tries v1beta, then v1.
    private func fetchModels() async throws -> [GeminiModelInfo] {
        var lastError: Error?
        for version in ["v1beta", "v1"] {
            do {
                let found = try await fetchModels(version: version)
                if !found.isEmpty { return found }
            } catch {
                lastError = error
            }
        }
        if let lastError { throw lastError }
        return []
    }

    private func fetchModels(version: String) async throws -> [GeminiModelInfo] {
        struct Listing: Decodable {
            struct Model: Decodable {
                let name: String
                let displayName: String?
                let description: String?
                let supportedGenerationMethods: [String]?
            }
            let models: [Model]?
        }

        let (data, code) = try await get("https://generativelanguage.googleapis.com/\(version)/models?pageSize=200")
        guard (200..<300).contains(code) else {
            throw NSError(domain: "LifeAI", code: code,
                          userInfo: [NSLocalizedDescriptionKey: Self.readableError(data: data, code: code)])
        }
        let listing = try JSONDecoder().decode(Listing.self, from: data)
        var out: [GeminiModelInfo] = []
        for model in listing.models ?? [] {
            let bare = model.name.replacingOccurrences(of: "models/", with: "")
            let methods = model.supportedGenerationMethods ?? []
            // Only chat models: no embeddings, no image generators, no TTS.
            guard methods.contains("generateContent") || methods.contains("streamGenerateContent") else { continue }
            guard bare.contains("gemini") else { continue }
            let lowered = bare.lowercased()
            let unwanted = ["embedding", "aqa", "image-generation", "-tts", "-live-", "native-audio", "thinking-exp"]
            guard !unwanted.contains(where: { lowered.contains($0) }) else { continue }
            out.append(GeminiModelInfo(name: bare,
                                       displayName: model.displayName ?? bare,
                                       detail: model.description ?? ""))
        }
        return out.sorted { Self.rank($0.name) < Self.rank($1.name) }
    }

    /// Flash first (cheap and quick), then Pro, newest before oldest.
    private static func rank(_ name: String) -> String {
        let lowered = name.lowercased()
        let family: String
        if lowered.contains("flash-lite") { family = "1" }
        else if lowered.contains("flash") { family = "0" }
        else if lowered.contains("pro") { family = "2" }
        else { family = "3" }
        // "latest" aliases outlive numbered names, so float them up.
        let stability = lowered.contains("latest") ? "0" : "1"
        return family + stability + name
    }

    @MainActor
    private func adopt(_ models: [GeminiModelInfo]) {
        guard !models.isEmpty else { return }
        availableModels = models
        // If the remembered model no longer exists, move to the best one that does.
        if !models.contains(where: { $0.name == modelName }) {
            modelName = models[0].name
        }
    }

    /// Loads the model list if it hasn't been loaded yet this launch.
    @MainActor
    func loadModelsIfNeeded() async {
        guard availableModels.isEmpty, isConfigured, !isLoadingModels else { return }
        isLoadingModels = true
        defer { isLoadingModels = false }
        do {
            let models = try await fetchModels()
            adopt(models)
        } catch {
            // Keep the starting guess; the first request retries on its own.
        }
    }

    @MainActor
    func reloadModels() async -> String? {
        isLoadingModels = true
        defer { isLoadingModels = false }
        do {
            let models = try await fetchModels()
            adopt(models)
            return models.isEmpty ? "No text models are available to this key." : nil
        } catch {
            return error.localizedDescription
        }
    }

    // MARK: Sending

    @MainActor
    func cancel() {
        task?.cancel()
        task = nil
        isStreaming = false
        activity = ""
    }

    /// Runs one turn: streams text into `partial`, calls `perform` for any
    /// action the model asks for, and returns the finished answer.
    @MainActor
    func send(history: [(role: String, text: String)],
              prompt: String,
              attachments: [AIAttachment] = [],
              systemPrompt: String,
              retrieve: @escaping @MainActor (String) -> (text: String, sources: [String]),
              perform: @escaping @MainActor (AIAction) -> String) async -> (text: String, sources: [String], actions: [String]) {

        guard isConfigured else {
            return ("I need a Gemini API key before I can answer. Settings → Life AI.", [], [])
        }

        isStreaming = true
        partial = ""
        activity = ""
        lastError = nil
        defer { isStreaming = false; activity = "" }

        // Make sure the chosen model actually exists before spending a request.
        await loadModelsIfNeeded()

        var turns: [GeminiRequest.Content] = history.map {
            .init(role: $0.role, parts: [.text($0.text)])
        }
        turns.append(.init(role: "user", parts: Self.parts(for: prompt, attachments: attachments)))

        var collectedSources: [String] = []
        var performed: [String] = []
        var answer = ""

        // Up to three rounds: the model may search, then act, then answer.
        for round in 0..<3 {
            let result: (text: String, calls: [AIAction])
            do {
                result = try await streamWithRecovery(turns: turns, systemPrompt: systemPrompt)
            } catch is CancellationError {
                return (answer.isEmpty ? "Stopped." : answer, collectedSources, performed)
            } catch {
                lastError = error.localizedDescription
                let note = answer.isEmpty ? "" : answer + "\n\n"
                return (note + "⚠️ \(error.localizedDescription)", collectedSources, performed)
            }

            if !result.text.isEmpty {
                answer = answer.isEmpty ? result.text : answer + "\n\n" + result.text
            }
            guard !result.calls.isEmpty, round < 2 else { break }

            // Record what the model asked for, so the next request has context.
            turns.append(.init(role: "model", parts: result.calls.map {
                GeminiRequest.Part(functionCall: .init(name: $0.name, args: $0.args))
            }))

            var responses: [GeminiRequest.Part] = []
            for call in result.calls {
                if call.name == "search_material" {
                    activity = "Reading your material…"
                    let query = call.args["query"] ?? prompt
                    let found = retrieve(query)
                    collectedSources.append(contentsOf: found.sources)
                    responses.append(GeminiRequest.Part(
                        functionResponse: .init(name: call.name, response: ["result": found.text])))
                } else {
                    activity = "Updating your \(Self.activityNoun(call.name))…"
                    let outcome = perform(call)
                    performed.append(outcome)
                    responses.append(GeminiRequest.Part(
                        functionResponse: .init(name: call.name, response: ["result": outcome])))
                }
            }
            turns.append(.init(role: "user", parts: responses))
            partial = answer
            activity = ""
        }

        collectedSources = Array(NSOrderedSet(array: collectedSources).compactMap { $0 as? String })
        return (answer.isEmpty ? "(no answer)" : answer, collectedSources, performed)
    }

    /// The user turn: the question, then each attachment as text or as bytes.
    private static func parts(for prompt: String, attachments: [AIAttachment]) -> [GeminiRequest.Part] {
        var parts: [GeminiRequest.Part] = []
        for file in attachments {
            if let text = file.text, !text.isEmpty {
                parts.append(.text("--- Attached file: \(file.name) ---\n\(text)\n--- end of \(file.name) ---"))
            } else if let bytes = file.data, let mime = file.mimeType {
                parts.append(.file(mime: mime, bytes: bytes))
            } else {
                parts.append(.text("(\(file.name) was attached but could not be read: \(file.note))"))
            }
        }
        parts.append(.text(prompt))
        return parts
    }

    /// Streams once; if the model name turns out to be unknown, re-discovers
    /// the list, switches to one that exists, and tries again — so a model
    /// Google renamed never becomes a dead end.
    @MainActor
    private func streamWithRecovery(turns: [GeminiRequest.Content],
                                    systemPrompt: String) async throws -> (text: String, calls: [AIAction]) {
        do {
            return try await stream(turns: turns, systemPrompt: systemPrompt)
        } catch let error as UnknownModelError {
            let before = modelName
            activity = "Finding a model this key can use…"
            let models = (try? await fetchModels()) ?? []
            adopt(models)
            activity = ""
            guard !models.isEmpty, modelName != before || !models.contains(where: { $0.name == before }) else {
                throw NSError(domain: "LifeAI", code: 404, userInfo: [NSLocalizedDescriptionKey:
                    "\(error.message)\n\nThe key also didn't return a model list, so the key itself may be the problem. Settings → Life AI → Test."])
            }
            if modelName == before, let first = models.first { modelName = first.name }
            partial = ""
            return try await stream(turns: turns, systemPrompt: systemPrompt)
        }
    }

    // MARK: One streamed request

    @MainActor
    private func stream(turns: [GeminiRequest.Content],
                        systemPrompt: String) async throws -> (text: String, calls: [AIAction]) {

        let model = modelName
        var request = URLRequest(url: try endpoint(
            "https://generativelanguage.googleapis.com/v1beta/models/\(model):streamGenerateContent",
            query: [URLQueryItem(name: "alt", value: "sse")]))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "x-goog-api-key")
        request.timeoutInterval = 180

        let body = GeminiRequest(
            contents: turns,
            systemInstruction: .init(parts: [.text(systemPrompt)]),
            tools: [.init(functionDeclarations: Self.toolDeclarations)],
            generationConfig: .init(temperature: 0.7, maxOutputTokens: 8192)
        )
        request.httpBody = try JSONEncoder().encode(body)

        let (bytes, response) = try await URLSession.shared.bytes(for: request)
        let code = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(code) else {
            // Error responses are plain JSON, not SSE — collect and report.
            var data = Data()
            for try await byte in bytes { data.append(byte); if data.count > 8192 { break } }
            let message = Self.readableError(data: data, code: code)
            if code == 404 { throw UnknownModelError(message: message) }
            throw NSError(domain: "LifeAI", code: code, userInfo: [NSLocalizedDescriptionKey: message])
        }

        var text = ""
        var calls: [AIAction] = []
        let decoder = JSONDecoder()

        for try await line in bytes.lines {
            try Task.checkCancellation()
            guard line.hasPrefix("data:") else { continue }
            let payload = line.dropFirst(5).trimmingCharacters(in: .whitespaces)
            guard !payload.isEmpty, payload != "[DONE]",
                  let data = payload.data(using: .utf8),
                  let chunk = try? decoder.decode(GeminiChunk.self, from: data) else { continue }

            if let message = chunk.error?.message {
                throw NSError(domain: "LifeAI", code: 0, userInfo: [NSLocalizedDescriptionKey: message])
            }
            for part in chunk.candidates?.first?.content?.parts ?? [] {
                if let piece = part.text, !piece.isEmpty {
                    text += piece
                    partial += piece
                }
                if let call = part.functionCall {
                    var args: [String: String] = [:]
                    for (key, value) in call.args ?? [:] { args[key] = value.stringValue }
                    calls.append(AIAction(name: call.name, args: args))
                }
            }
        }
        return (text.trimmingCharacters(in: .whitespacesAndNewlines), calls)
    }

    // MARK: Plumbing

    /// Builds a URL with the key as a query item as well as a header. Some
    /// Google keys are only accepted one way, so the app sends both.
    private func endpoint(_ base: String, query: [URLQueryItem] = []) throws -> URL {
        guard var components = URLComponents(string: base) else {
            throw NSError(domain: "LifeAI", code: 0,
                          userInfo: [NSLocalizedDescriptionKey: "Bad endpoint."])
        }
        components.queryItems = query + [URLQueryItem(name: "key", value: apiKey)]
        guard let url = components.url else {
            throw NSError(domain: "LifeAI", code: 0,
                          userInfo: [NSLocalizedDescriptionKey: "Bad endpoint."])
        }
        return url
    }

    private func get(_ base: String) async throws -> (Data, Int) {
        var request = URLRequest(url: try endpoint(base))
        request.setValue(apiKey, forHTTPHeaderField: "x-goog-api-key")
        request.timeoutInterval = 30
        let (data, response) = try await URLSession.shared.data(for: request)
        return (data, (response as? HTTPURLResponse)?.statusCode ?? 0)
    }

    private static func activityNoun(_ tool: String) -> String {
        switch tool {
        case "add_reminder":       return "reminders"
        case "add_schedule_block": return "schedule"
        case "add_calendar_mark":  return "calendar"
        case "add_habit":          return "habits"
        case "add_syllabus_topic": return "syllabus"
        case "add_subject_note":   return "notes"
        default:                   return "app"
        }
    }

    /// Google's own message, with a hint about what to do — never a guess that
    /// hides what actually went wrong.
    private static func readableError(data: Data, code: Int) -> String {
        struct Wrapper: Decodable { struct E: Decodable { let message: String? }; let error: E? }
        let message = (try? JSONDecoder().decode(Wrapper.self, from: data))?.error?.message
        let detail = message ?? "Gemini returned \(code)."
        switch code {
        case 400 where detail.lowercased().contains("api key"):
            return "\(detail)\n\nCheck the key in Settings → Life AI."
        case 401, 403:
            return "\(detail)\n\nThe key may be restricted, or the Generative Language API may not be enabled for its project."
        case 404:
            return "\(detail)\n\nPicking a different model from the ⋯ menu usually fixes this."
        case 429:
            return "\(detail)\n\nWait a minute, or switch to a Flash Lite model."
        default:
            return detail
        }
    }

    // MARK: Tools

    private static let toolDeclarations: [GeminiRequest.FunctionDeclaration] = [
        .init(name: "search_material",
              description: "Search the user's own uploaded course material (PDFs, PowerPoints, Word files, syllabus topics and saved links) for passages relevant to a question. Use this whenever the question is about their specific subjects, lectures, syllabus or notes rather than general knowledge. Do NOT use it for a file attached to the current message — that is already in front of you.",
              parameters: .object([
                "query": .string("What to look for, in the language the material is likely written in.")
              ], required: ["query"])),

        .init(name: "add_reminder",
              description: "Add a study reminder to the Study page. Use for anything the user should do that is not tied to a clock time.",
              parameters: .object([
                "title": .string("Short reminder text, e.g. 'Finish CV lab report'.")
              ], required: ["title"])),

        .init(name: "add_schedule_block",
              description: "Add a timed block to the Schedule page for a recurring part of the day.",
              parameters: .object([
                "title": .string("What the block is for."),
                "start": .string("Start time as HH:MM in 24-hour form."),
                "end": .string("End time as HH:MM in 24-hour form."),
                "reminder": .bool("Whether to notify the user before it starts.")
              ], required: ["title", "start", "end"])),

        .init(name: "add_calendar_mark",
              description: "Mark a specific date on the Calendar page — an exam, a deadline, a submission, a holiday.",
              parameters: .object([
                "date": .string("The date as YYYY-MM-DD."),
                "title": .string("What is happening that day."),
                "kind": .string("'event' for something informational, 'habit' for a one-off task to tick off that day.")
              ], required: ["date", "title"])),

        .init(name: "add_habit",
              description: "Add a habit to track daily or on chosen days.",
              parameters: .object([
                "name": .string("The habit, e.g. 'Revise DSA for 30 minutes'."),
                "frequency": .string("One of: daily, weekdays, weekends.")
              ], required: ["name"])),

        .init(name: "add_syllabus_topic",
              description: "Add a topic to a subject's syllabus checklist.",
              parameters: .object([
                "subject": .string("The subject name exactly as it appears in the app."),
                "title": .string("The topic to add.")
              ], required: ["subject", "title"])),

        .init(name: "add_subject_note",
              description: "Append text to a subject's Notes. Use when the user asks you to save a summary, explanation or set of notes into a subject. Only use it when they ask — they can also save any answer themselves with the button under it.",
              parameters: .object([
                "subject": .string("The subject name exactly as it appears in the app."),
                "heading": .string("A short title for this note."),
                "body": .string("The note itself, in Markdown.")
              ], required: ["subject", "body"]))
    ]

    // MARK: Personality

    /// The standing instructions. `snapshot` is the app-data digest built by
    /// `AIContextBuilder` — it changes every time you send a message.
    static func systemPrompt(snapshot: String) -> String {
        """
        You are Life AI, the assistant built into LifeTracker — a study and life \
        tracking app made by Pranav Ashok Pande, a student at D Y Patil \
        International University. You are talking to him inside the app.

        You are a full general-purpose assistant first: write and debug code in \
        any language, explain concepts, translate, draft text, do maths, answer \
        ordinary questions. Do all of that as well as you possibly can, with no \
        reference to the app unless it is relevant.

        On top of that, you can see his tracked data (below), read files he \
        attaches, search his own course material, and change things in the app \
        through the tools you have been given.

        How to behave:
        • Be concise and direct. No preamble, no "Great question!", no restating \
          what he asked. Give the answer, then stop.
        • Use his real data whenever it makes the answer better. Name actual \
          subjects, habits and deadlines rather than speaking generally.
        • When a file is attached to the message, work from that file. When he \
          asks about his subjects, lectures or syllabus in general, call \
          search_material first and answer from what comes back. Say plainly when \
          the material does not cover something rather than filling the gap.
        • Summarising a document: lead with what it is in one line, then the \
          substance as short sections, then anything that looks examinable. Keep \
          the document's own terminology and its language.
        • When he asks you to plan, remind, schedule or mark something, use the \
          tools — do not just describe what he should add. One tool call per \
          item, then confirm briefly in one line.
        • Never invent a number about his progress. Everything factual about him \
          comes from the snapshot below, an attached file, or search_material.
        • Format with Markdown. Fenced code blocks with a language tag for code. \
          Keep lists short.
        • Match his language: reply in English, Korean or Chinese depending on how \
          he writes, or in the language of the document he attached.
        • His Journal is private and deliberately not shown to you. If he asks \
          about it, say so — do not guess at its contents.

        Today is \(Self.longDate(.now)).

        ────────────────────────────────────
        HIS DATA RIGHT NOW
        ────────────────────────────────────
        \(snapshot)
        """
    }

    static func longDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEEE, d MMMM yyyy"
        return f.string(from: date)
    }
}
