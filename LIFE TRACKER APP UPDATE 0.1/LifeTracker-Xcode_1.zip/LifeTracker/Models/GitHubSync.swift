import Foundation
import SwiftUI

// MARK: - GitHub, without the terminal
//
// Everything here talks to the GitHub REST API with a personal access token
// kept in the Keychain. No git, no clone, no commit commands: a file you drop
// becomes a commit through the Contents API, which is exactly what the web
// "Upload files" button does.
//
// Token scopes: `repo` covers reading, creating and pushing. Add
// `delete_repo` as well if you want the app to delete whole repositories.

struct GitHubUser: Codable, Equatable {
    let login: String
    let name: String?
    let avatar_url: String?
}

struct GitHubRepo: Codable, Identifiable, Equatable, Hashable {
    let id: Int
    let name: String
    let full_name: String
    /// GitHub calls this "private", which is a Swift keyword — renamed here.
    let isPrivate: Bool
    let description: String?
    let default_branch: String?
    let html_url: String
    let updated_at: String?
    let size: Int?

    enum CodingKeys: String, CodingKey {
        case id, name, full_name, description, default_branch, html_url, updated_at, size
        case isPrivate = "private"
    }

    var owner: String { full_name.components(separatedBy: "/").first ?? "" }
    var branch: String { default_branch ?? "main" }
}

/// One entry in a repository folder.
struct GitHubEntry: Codable, Identifiable, Equatable {
    let name: String
    let path: String
    let sha: String
    let size: Int?
    let type: String          // "file" | "dir"
    let html_url: String?
    let download_url: String?

    var id: String { path }
    var isDirectory: Bool { type == "dir" }
}

enum GitHubError: LocalizedError {
    case noToken
    case http(Int, String)
    case badResponse
    case tooLarge(String)

    var errorDescription: String? {
        switch self {
        case .noToken:
            return "Connect a GitHub token first."
        case .http(let code, let message):
            switch code {
            case 401: return "GitHub rejected the token (401). It may be expired or mistyped."
            case 403: return "GitHub refused (403). The token is probably missing a scope — \(message)"
            case 404: return "Not found (404). Either it doesn't exist or the token can't see it."
            case 409: return "That repository is empty or the branch doesn't exist yet (409)."
            case 422: return "GitHub wouldn't accept that: \(message)"
            default: return "GitHub error \(code): \(message)"
            }
        case .badResponse:
            return "GitHub sent something unexpected."
        case .tooLarge(let name):
            return "“\(name)” is over 50 MB — GitHub's upload API won't take it."
        }
    }
}

final class GitHubSync: ObservableObject {
    static let shared = GitHubSync()

    @Published private(set) var user: GitHubUser?
    @Published private(set) var repos: [GitHubRepo] = []
    @Published private(set) var isBusy = false
    @Published var status: String = ""
    @Published var lastError: String?

    /// 0…1 while a batch of files is uploading.
    @Published var progress: Double = 0
    @Published var progressLabel: String = ""

    private static let tokenKey = "github.token"
    /// GitHub's Contents API tops out around 100 MB; keep a safe margin.
    static let maxUploadBytes = 50 * 1024 * 1024

    private init() {
        if isConnected { Task { @MainActor in await refresh() } }
    }

    // MARK: Token

    var token: String? {
        let value = Keychain.get(Self.tokenKey)
        return (value?.isEmpty ?? true) ? nil : value
    }
    var isConnected: Bool { token != nil }

    /// Stores the token and checks it by asking GitHub who it belongs to.
    @MainActor
    @discardableResult
    func connect(token raw: String) async -> Bool {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return false }
        Keychain.set(trimmed, for: Self.tokenKey)
        lastError = nil
        do {
            user = try await get("user", as: GitHubUser.self)
            status = "Connected as @\(user?.login ?? "")"
            await loadRepos()
            return true
        } catch {
            Keychain.set(nil, for: Self.tokenKey)
            user = nil
            lastError = error.localizedDescription
            return false
        }
    }

    @MainActor
    func disconnect() {
        Keychain.set(nil, for: Self.tokenKey)
        user = nil
        repos = []
        status = ""
        lastError = nil
    }

    @MainActor
    func refresh() async {
        guard isConnected else { return }
        do {
            user = try await get("user", as: GitHubUser.self)
            await loadRepos()
        } catch {
            lastError = error.localizedDescription
        }
    }

    // MARK: Repos

    @MainActor
    func loadRepos() async {
        guard isConnected else { return }
        isBusy = true
        defer { isBusy = false }
        do {
            var all: [GitHubRepo] = []
            var page = 1
            while page <= 5 {
                let batch = try await get("user/repos?per_page=100&sort=updated&affiliation=owner,collaborator&page=\(page)",
                                          as: [GitHubRepo].self)
                all += batch
                if batch.count < 100 { break }
                page += 1
            }
            repos = all
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    @MainActor
    @discardableResult
    func createRepo(name: String, description: String, isPrivate: Bool, addReadme: Bool) async -> GitHubRepo? {
        let clean = Self.slug(name)
        guard !clean.isEmpty else { return nil }
        isBusy = true
        defer { isBusy = false }
        do {
            let body: [String: Any] = ["name": clean,
                                       "description": description,
                                       "private": isPrivate,
                                       "auto_init": addReadme]
            let repo = try await send("user/repos", method: "POST", json: body, as: GitHubRepo.self)
            repos.insert(repo, at: 0)
            status = "Created \(repo.full_name)"
            lastError = nil
            return repo
        } catch {
            lastError = error.localizedDescription
            return nil
        }
    }

    @MainActor
    func deleteRepo(_ repo: GitHubRepo) async -> Bool {
        isBusy = true
        defer { isBusy = false }
        do {
            _ = try await sendRaw("repos/\(repo.full_name)", method: "DELETE", body: nil)
            repos.removeAll { $0.id == repo.id }
            status = "Deleted \(repo.full_name)"
            lastError = nil
            return true
        } catch {
            lastError = error.localizedDescription
            return false
        }
    }

    // MARK: Browsing

    @MainActor
    func contents(of repo: GitHubRepo, path: String) async -> [GitHubEntry] {
        let encoded = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        do {
            let entries = try await get("repos/\(repo.full_name)/contents/\(encoded)", as: [GitHubEntry].self)
            lastError = nil
            return entries.sorted {
                $0.isDirectory == $1.isDirectory
                ? $0.name.localizedStandardCompare($1.name) == .orderedAscending
                : $0.isDirectory
            }
        } catch {
            // An empty repository answers 404/409 — not worth shouting about.
            if let github = error as? GitHubError, case .http(let code, _) = github,
               code == 404 || code == 409 {
                lastError = nil
            } else {
                lastError = error.localizedDescription
            }
            return []
        }
    }

    @MainActor
    func delete(_ entry: GitHubEntry, in repo: GitHubRepo, message: String) async -> Bool {
        let encoded = entry.path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? entry.path
        do {
            let body: [String: Any] = ["message": message.isEmpty ? "Delete \(entry.name)" : message,
                                       "sha": entry.sha,
                                       "branch": repo.branch]
            _ = try await sendRaw("repos/\(repo.full_name)/contents/\(encoded)", method: "DELETE", body: body)
            status = "Deleted \(entry.path)"
            lastError = nil
            return true
        } catch {
            lastError = error.localizedDescription
            return false
        }
    }

    // MARK: Uploading

    struct Upload: Identifiable {
        let id = UUID()
        let localURL: URL
        /// Where it lands in the repo, e.g. "notes/week-3/slides.pdf".
        var remotePath: String
        let byteCount: Int
    }

    /// Expands whatever you dropped into a flat list of files. A folder keeps
    /// its shape: dropping `Sem5/` puts everything under `Sem5/…` in the repo.
    static func expand(_ urls: [URL], into folder: String) -> [Upload] {
        var uploads: [Upload] = []
        let fm = FileManager.default
        let prefix = folder.trimmingCharacters(in: CharacterSet(charactersIn: " /"))

        func add(_ url: URL, path: String) {
            let size = ((try? fm.attributesOfItem(atPath: url.path)[.size]) as? Int) ?? 0
            let full = prefix.isEmpty ? path : "\(prefix)/\(path)"
            uploads.append(Upload(localURL: url, remotePath: full, byteCount: size))
        }

        for url in urls {
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: url.path, isDirectory: &isDir) else { continue }
            if isDir.boolValue {
                let root = url.lastPathComponent
                let enumerator = fm.enumerator(at: url, includingPropertiesForKeys: [.isRegularFileKey],
                                               options: [.skipsHiddenFiles, .skipsPackageDescendants])
                while let child = enumerator?.nextObject() as? URL {
                    var childIsDir: ObjCBool = false
                    fm.fileExists(atPath: child.path, isDirectory: &childIsDir)
                    if childIsDir.boolValue { continue }
                    let relative = child.path.replacingOccurrences(of: url.path + "/", with: "")
                    add(child, path: "\(root)/\(relative)")
                }
            } else {
                add(url, path: url.lastPathComponent)
            }
        }
        return uploads
    }

    /// Pushes every file, one commit each (that's what the Contents API does).
    /// Returns the files that failed, with the reason.
    @MainActor
    func push(_ uploads: [Upload], to repo: GitHubRepo, message: String) async -> [(String, String)] {
        guard !uploads.isEmpty else { return [] }
        isBusy = true
        progress = 0
        var failures: [(String, String)] = []
        let commit = message.trimmingCharacters(in: .whitespacesAndNewlines)

        for (index, upload) in uploads.enumerated() {
            progressLabel = upload.remotePath
            progress = Double(index) / Double(uploads.count)

            if upload.byteCount > Self.maxUploadBytes {
                failures.append((upload.remotePath, "over 50 MB"))
                continue
            }
            guard let data = try? Data(contentsOf: upload.localURL) else {
                failures.append((upload.remotePath, "couldn't be read"))
                continue
            }
            let encoded = upload.remotePath.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? upload.remotePath
            let existing = try? await get("repos/\(repo.full_name)/contents/\(encoded)?ref=\(repo.branch)",
                                          as: GitHubEntry.self)
            var body: [String: Any] = [
                "message": commit.isEmpty ? "Add \((upload.remotePath as NSString).lastPathComponent) from LifeTracker" : commit,
                "content": data.base64EncodedString(),
                "branch": repo.branch
            ]
            if let sha = existing?.sha { body["sha"] = sha }     // updates instead of failing

            do {
                _ = try await sendRaw("repos/\(repo.full_name)/contents/\(encoded)", method: "PUT", body: body)
            } catch {
                failures.append((upload.remotePath, error.localizedDescription))
            }
        }

        progress = 1
        progressLabel = ""
        isBusy = false
        let done = uploads.count - failures.count
        status = failures.isEmpty
            ? "Pushed \(done) file\(done == 1 ? "" : "s") to \(repo.full_name)"
            : "Pushed \(done) of \(uploads.count) — \(failures.count) failed"
        lastError = failures.isEmpty ? nil : failures.map { "\($0.0): \($0.1)" }.joined(separator: "\n")
        return failures
    }

    // MARK: REST plumbing

    private func request(_ path: String, method: String) throws -> URLRequest {
        guard let token else { throw GitHubError.noToken }
        guard let url = URL(string: "https://api.github.com/" + path) else { throw GitHubError.badResponse }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        request.setValue("LifeTracker", forHTTPHeaderField: "User-Agent")
        return request
    }

    @discardableResult
    private func sendRaw(_ path: String, method: String, body: [String: Any]?) async throws -> Data {
        var request = try self.request(path, method: method)
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        let code = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(code) else {
            throw GitHubError.http(code, Self.message(from: data))
        }
        return data
    }

    private func get<T: Decodable>(_ path: String, as type: T.Type) async throws -> T {
        let data = try await sendRaw(path, method: "GET", body: nil)
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            throw GitHubError.badResponse
        }
    }

    private func send<T: Decodable>(_ path: String, method: String, json: [String: Any], as type: T.Type) async throws -> T {
        let data = try await sendRaw(path, method: method, body: json)
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            throw GitHubError.badResponse
        }
    }

    private static func message(from data: Data) -> String {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return "" }
        let main = (object["message"] as? String) ?? ""
        if let errors = object["errors"] as? [[String: Any]] {
            let detail: [String] = errors.compactMap { item in
                if let text = item["message"] as? String { return text }
                return item["field"] as? String
            }
            if !detail.isEmpty { return "\(main) (\(detail.joined(separator: ", ")))" }
        }
        return main
    }

    /// GitHub repo names allow letters, digits, dot, dash and underscore.
    static func slug(_ raw: String) -> String {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
        let replaced = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: " ", with: "-")
        return String(String.UnicodeScalarView(replaced.unicodeScalars.filter { allowed.contains($0) }))
    }
}
