import SwiftUI
import UniformTypeIdentifiers
#if os(macOS)
import AppKit
#else
import UIKit
#endif

// MARK: - GitHub page (Study → GitHub)
//
// Drop files or a folder, pick a repo (or make one), press Push. No commands,
// no clone, no staging area — the same three steps every time.

struct GitHubView: View {
    @Environment(\.openURL) private var openURL
    @Environment(\.layoutWidth) private var width
    @ObservedObject private var hub = GitHubSync.shared

    @AppStorage("github.lastRepo") private var lastRepoFullName: String = ""

    @State private var selected: GitHubRepo?
    @State private var staged: [GitHubSync.Upload] = []
    @State private var folder = ""
    @State private var message = ""
    @State private var dropTargeted = false
    @State private var importing = false
    @State private var creatingRepo = false
    @State private var showToken = false
    @State private var search = ""
    @State private var browsePath = ""
    @State private var entries: [GitHubEntry] = []
    @State private var loadingEntries = false
    @State private var deletingEntry: GitHubEntry?
    @State private var deletingRepo: GitHubRepo?
    @State private var toast: String?

    private var compact: Bool { AppLayout.isCompact(width) }

    private var visibleRepos: [GitHubRepo] {
        let query = search.trimmingCharacters(in: .whitespaces).lowercased()
        guard !query.isEmpty else { return hub.repos }
        return hub.repos.filter { $0.name.lowercased().contains(query) || $0.full_name.lowercased().contains(query) }
    }

    var body: some View {
        Group {
            if hub.isConnected {
                connected
            } else {
                GitHubConnectCard { showToken = true }
            }
        }
        .background(Palette.surface)
        .navigationTitle("GitHub")
        .blendedToolbar()
        .sheet(isPresented: $showToken) {
            GitHubTokenSheet { message in show(message) }
        }
        .sheet(isPresented: $creatingRepo) {
            NewRepoSheet { repo in
                selected = repo
                lastRepoFullName = repo.full_name
                show("Created \(repo.full_name)")
                Task { await loadEntries() }
            }
        }
        .task {
            if hub.isConnected && hub.repos.isEmpty { await hub.loadRepos() }
            restoreSelection()
        }
        .onChange(of: hub.repos) { _, _ in restoreSelection() }
        .confirmationDialog(deletingRepo.map { "Delete \($0.full_name)?" } ?? "Delete repository?",
                            isPresented: Binding(get: { deletingRepo != nil },
                                                 set: { if !$0 { deletingRepo = nil } }),
                            titleVisibility: .visible,
                            presenting: deletingRepo) { repo in
            Button("Delete on GitHub", role: .destructive) {
                Task {
                    if await hub.deleteRepo(repo) {
                        if selected?.id == repo.id { selected = nil; entries = [] }
                        show("Deleted \(repo.full_name)")
                    } else {
                        show(hub.lastError ?? "Couldn't delete that repository")
                    }
                    deletingRepo = nil
                }
            }
            Button("Cancel", role: .cancel) { deletingRepo = nil }
        } message: { _ in
            Text("This deletes the repository and everything in it on GitHub, for good. Your token needs the delete_repo scope.")
        }
        .confirmationDialog(deletingEntry.map { "Delete “\($0.name)”?" } ?? "Delete file?",
                            isPresented: Binding(get: { deletingEntry != nil },
                                                 set: { if !$0 { deletingEntry = nil } }),
                            titleVisibility: .visible,
                            presenting: deletingEntry) { entry in
            Button("Delete", role: .destructive) {
                Task {
                    guard let repo = selected else { return }
                    if await hub.delete(entry, in: repo, message: "Delete \(entry.name)") {
                        show("Deleted \(entry.name)")
                        await loadEntries()
                    } else {
                        show(hub.lastError ?? "Couldn't delete that file")
                    }
                    deletingEntry = nil
                }
            }
            Button("Cancel", role: .cancel) { deletingEntry = nil }
        } message: { _ in
            Text("It's removed from the repository with a commit. The history keeps the old version.")
        }
        .overlay(alignment: .bottom) {
            if let toast {
                Text(toast)
                    .font(.mono(12))
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(Palette.callout, in: Capsule())
                    .overlay(Capsule().strokeBorder(Palette.hairline))
                    .padding(.bottom, 18)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    // MARK: Connected layout

    private var connected: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                header
                dropZone
                if !staged.isEmpty { stagedList }
                repoPicker
                if selected != nil { repoContents }
            }
            .padding(AppLayout.pagePadding(width))
            .frame(maxWidth: 1000, alignment: .leading)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .dropDestination(for: URL.self) { urls, _ in
            stage(urls.filter(\.isFileURL))
            return true
        } isTargeted: { dropTargeted = $0 }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.item, .folder],
                      allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { stage(urls) }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "chevron.left.forwardslash.chevron.right")
                .font(.system(size: 20))
                .foregroundStyle(Palette.onAccent)
                .frame(width: 42, height: 42)
                .background(Color(hex: "24292F"), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(hub.user?.name ?? hub.user?.login ?? "GitHub")
                    .font(.mono(18, .bold))
                Text("@\(hub.user?.login ?? "") · \(hub.repos.count) repositor\(hub.repos.count == 1 ? "y" : "ies")")
                    .font(.mono(11)).foregroundStyle(Palette.mutedText)
            }
            Spacer()
            if hub.isBusy { ProgressView().controlSize(.small) }
            Button { Task { await hub.loadRepos() } } label: {
                Image(systemName: "arrow.clockwise")
            }
            .help("Reload your repositories")
            Menu {
                Button("Open GitHub in browser") {
                    if let url = URL(string: "https://github.com/\(hub.user?.login ?? "")") { openURL(url) }
                }
                Button("Change token…") { showToken = true }
                Divider()
                Button("Disconnect", role: .destructive) {
                    Task { @MainActor in
                        hub.disconnect()
                        selected = nil
                        entries = []
                    }
                }
            } label: {
                Image(systemName: "ellipsis.circle")
            }
            .menuStyle(.button)
            .buttonStyle(.borderless)
            .menuIndicator(.hidden)
            .frame(width: 32)
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
    }

    // MARK: Drop zone

    private var dropZone: some View {
        Button { importing = true } label: {
            VStack(spacing: 10) {
                Image(systemName: dropTargeted ? "tray.and.arrow.down.fill" : "tray.and.arrow.down")
                    .font(.system(size: 30, weight: .light))
                Text(staged.isEmpty ? "Drop files or a folder here" : "Drop more")
                    .font(.mono(15, .semibold))
                Text("Any file type. A folder keeps its structure — drop “Sem5” and the repo gets Sem5/… exactly as it is on disk.")
                    .font(.mono(11)).multilineTextAlignment(.center)
                    .foregroundStyle(Palette.mutedText)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, staged.isEmpty ? 44 : 26)
            .background(dropTargeted ? StudyPalette.callout : Color.clear,
                        in: RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12)
                .strokeBorder(dropTargeted ? Palette.accent : StudyPalette.line,
                              style: StrokeStyle(lineWidth: 1.5, dash: [6, 5])))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: Staged files

    private var stagedList: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                heading("ready to push")
                Spacer()
                Text("\(staged.count) file\(staged.count == 1 ? "" : "s") · \(ByteCountFormatter.string(fromByteCount: Int64(staged.reduce(0) { $0 + $1.byteCount }), countStyle: .file))")
                    .font(.mono(11)).foregroundStyle(Palette.mutedText)
                Button("Clear") { staged = [] }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
            }

            VStack(spacing: 6) {
                ForEach(staged) { item in
                    HStack(spacing: 10) {
                        Image(systemName: MaterialKind.of((item.remotePath as NSString).pathExtension).icon)
                            .font(.system(size: 13))
                            .foregroundStyle(MaterialKind.of((item.remotePath as NSString).pathExtension).color)
                            .frame(width: 20)
                        Text(item.remotePath)
                            .font(.mono(12))
                            .lineLimit(1)
                            .truncationMode(.middle)
                        Spacer(minLength: 8)
                        if item.byteCount > GitHubSync.maxUploadBytes {
                            Text("too big")
                                .font(.mono(10, .semibold))
                                .foregroundStyle(Color(hex: "C0453F"))
                        } else {
                            Text(ByteCountFormatter.string(fromByteCount: Int64(item.byteCount), countStyle: .file))
                                .font(.mono(10)).foregroundStyle(Palette.mutedText)
                        }
                        Button(role: .destructive) {
                            staged.removeAll { $0.id == item.id }
                        } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(Palette.mutedText)
                                .frame(width: 20, height: 20)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(Palette.elevated, in: RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(Palette.hairline))
                }
            }

            ViewThatFits(in: .horizontal) {
                HStack(spacing: 8) { folderField; messageField; pushButton }
                VStack(spacing: 8) {
                    folderField
                    HStack(spacing: 8) { messageField; pushButton }
                }
            }

            if hub.isBusy && hub.progress > 0 {
                VStack(alignment: .leading, spacing: 4) {
                    ProgressView(value: hub.progress)
                    Text(hub.progressLabel)
                        .font(.mono(10)).foregroundStyle(Palette.mutedText).lineLimit(1)
                }
            }
            if let error = hub.lastError {
                Text(error)
                    .font(.mono(11)).foregroundStyle(Color(hex: "C0453F"))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .background(StudyPalette.cardFill, in: RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(StudyPalette.line))
    }

    private var folderField: some View {
        TextField("Folder in repo (optional)", text: $folder)
            .textFieldStyle(.roundedBorder)
            .font(.mono(12))
            #if os(iOS)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            #endif
    }

    private var messageField: some View {
        TextField("Commit message (optional)", text: $message)
            .textFieldStyle(.roundedBorder)
            .font(.mono(12))
    }

    private var pushButton: some View {
        Button {
            push()
        } label: {
            Label(selected == nil ? "Pick a repo" : "Push to \(selected?.name ?? "")",
                  systemImage: "arrow.up.circle.fill")
                .lineLimit(1)
        }
        .buttonStyle(.borderedProminent)
        .tint(Color(hex: "2DA44E"))
        .disabled(selected == nil || staged.isEmpty || hub.isBusy)
    }

    // MARK: Repo picker

    private var repoPicker: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                heading("repositories")
                Spacer()
                TextField("Search", text: $search)
                    .textFieldStyle(.roundedBorder)
                    .font(.mono(11))
                    .frame(maxWidth: 180)
                Button { creatingRepo = true } label: {
                    Label("New repo", systemImage: "plus")
                }
                .buttonStyle(.borderedProminent)
                .tint(StudyPalette.brown)
                .controlSize(.small)
            }

            if hub.repos.isEmpty && !hub.isBusy {
                Text("No repositories yet — make one with New repo and push straight into it.")
                    .font(.mono(12)).foregroundStyle(Palette.mutedText)
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 220, maximum: 320), spacing: 12)], spacing: 12) {
                ForEach(visibleRepos) { repo in
                    RepoCard(repo: repo,
                             isSelected: selected?.id == repo.id,
                             onOpen: { if let url = URL(string: repo.html_url) { openURL(url) } },
                             onDelete: { deletingRepo = repo })
                        .onTapGesture {
                            selected = repo
                            lastRepoFullName = repo.full_name
                            browsePath = ""
                            Task { await loadEntries() }
                        }
                }
            }
        }
    }

    // MARK: Repo contents

    private var repoContents: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                heading("files in \(selected?.name ?? "")")
                Spacer()
                if loadingEntries { ProgressView().controlSize(.small) }
                if !browsePath.isEmpty {
                    Button {
                        browsePath = (browsePath as NSString).deletingLastPathComponent
                        Task { await loadEntries() }
                    } label: {
                        Label("Up", systemImage: "arrow.turn.left.up")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
            }

            if !browsePath.isEmpty {
                Text("/\(browsePath)")
                    .font(.mono(11)).foregroundStyle(Palette.mutedText)
            }

            if entries.isEmpty && !loadingEntries {
                Text("Nothing here yet.")
                    .font(.mono(12)).foregroundStyle(Palette.mutedText)
            }

            VStack(spacing: 6) {
                ForEach(entries) { entry in
                    HStack(spacing: 10) {
                        Image(systemName: entry.isDirectory
                              ? "folder.fill"
                              : MaterialKind.of((entry.name as NSString).pathExtension).icon)
                            .font(.system(size: 13))
                            .foregroundStyle(entry.isDirectory
                                             ? StudyPalette.brown
                                             : MaterialKind.of((entry.name as NSString).pathExtension).color)
                            .frame(width: 20)
                        Text(entry.name)
                            .font(.mono(12))
                            .lineLimit(1)
                        Spacer(minLength: 8)
                        if let size = entry.size, !entry.isDirectory {
                            Text(ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file))
                                .font(.mono(10)).foregroundStyle(Palette.mutedText)
                        }
                        if let link = entry.html_url, let url = URL(string: link) {
                            Button { openURL(url) } label: {
                                Image(systemName: "arrow.up.right")
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundStyle(Palette.mutedText)
                                    .frame(width: 20, height: 20)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .help("Open on GitHub")
                        }
                        if !entry.isDirectory {
                            Button(role: .destructive) {
                                deletingEntry = entry
                            } label: {
                                Image(systemName: "trash")
                                    .font(.system(size: 11))
                                    .foregroundStyle(Palette.mutedText)
                                    .frame(width: 20, height: 20)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .help("Delete this file from the repo")
                        }
                    }
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(Palette.elevated, in: RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(Palette.hairline))
                    .contentShape(Rectangle())
                    .onTapGesture {
                        guard entry.isDirectory else { return }
                        browsePath = entry.path
                        Task { await loadEntries() }
                    }
                }
            }
        }
    }

    // MARK: Actions

    private func heading(_ text: String) -> some View {
        Text(text.lowercased())
            .font(.mono(14, .bold))
            .italic()
            .foregroundStyle(Palette.accent)
    }

    private func restoreSelection() {
        guard selected == nil, !lastRepoFullName.isEmpty,
              let match = hub.repos.first(where: { $0.full_name == lastRepoFullName }) else { return }
        selected = match
        Task { await loadEntries() }
    }

    private func stage(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        var accessed: [URL] = []
        for url in urls where url.startAccessingSecurityScopedResource() { accessed.append(url) }
        defer { accessed.forEach { $0.stopAccessingSecurityScopedResource() } }

        let expanded = GitHubSync.expand(urls, into: "")
        guard !expanded.isEmpty else {
            show("Nothing readable in that drop")
            return
        }

        // Copy the bytes now, while the drop still grants access. By the time
        // you press Push that permission is gone and the originals would be
        // unreadable — which is how a "successful" push ends up empty.
        let fm = FileManager.default
        let root = fm.temporaryDirectory
            .appendingPathComponent("GitHubStaging/\(UUID().uuidString)", isDirectory: true)
        var copies: [GitHubSync.Upload] = []
        for item in expanded {
            let destination = root.appendingPathComponent(item.remotePath)
            do {
                try fm.createDirectory(at: destination.deletingLastPathComponent(),
                                       withIntermediateDirectories: true)
                try fm.copyItem(at: item.localURL, to: destination)
                copies.append(GitHubSync.Upload(localURL: destination,
                                                remotePath: item.remotePath,
                                                byteCount: item.byteCount))
            } catch {
                continue
            }
        }

        guard !copies.isEmpty else {
            show("Couldn't read those files")
            return
        }
        let existing = Set(staged.map(\.remotePath))
        staged += copies.filter { !existing.contains($0.remotePath) }
    }

    private func loadEntries() async {
        guard let repo = selected else { return }
        loadingEntries = true
        entries = await hub.contents(of: repo, path: browsePath)
        loadingEntries = false
    }

    private func push() {
        guard let repo = selected else { return }
        let prefix = folder.trimmingCharacters(in: CharacterSet(charactersIn: " /"))
        let uploads = staged.map { item -> GitHubSync.Upload in
            var copy = item
            if !prefix.isEmpty { copy.remotePath = "\(prefix)/\(item.remotePath)" }
            return copy
        }
        Task { @MainActor in
            let failures = await hub.push(uploads, to: repo, message: message)
            if failures.isEmpty {
                staged = []
                message = ""
                show("Pushed \(uploads.count) file\(uploads.count == 1 ? "" : "s") to \(repo.name)")
            } else {
                staged = staged.filter { item in
                    failures.contains { $0.0.hasSuffix(item.remotePath) }
                }
                show("\(failures.count) file\(failures.count == 1 ? "" : "s") didn't go through")
            }
            await loadEntries()
        }
    }

    private func show(_ text: String) {
        withAnimation { toast = text }
        Task {
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            withAnimation { toast = nil }
        }
    }
}

// MARK: - Repo card

private struct RepoCard: View {
    let repo: GitHubRepo
    let isSelected: Bool
    var onOpen: () -> Void
    var onDelete: () -> Void
    @State private var hovering = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: repo.isPrivate ? "lock.fill" : "book")
                    .font(.system(size: 11))
                    .foregroundStyle(repo.isPrivate ? StudyPalette.brown : Palette.mutedText)
                Text(repo.name)
                    .font(.mono(13, .semibold))
                    .lineLimit(1)
                Spacer(minLength: 4)
                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 13))
                        .foregroundStyle(Color(hex: "2DA44E"))
                }
            }
            Text(repo.description?.isEmpty == false ? repo.description! : "No description")
                .font(.mono(10))
                .foregroundStyle(Palette.mutedText)
                .lineLimit(2)
                .frame(maxWidth: .infinity, minHeight: 26, alignment: .topLeading)
            HStack(spacing: 6) {
                Text(repo.branch)
                    .font(.mono(9))
                    .padding(.horizontal, 6).padding(.vertical, 2)
                    .background(Palette.subtleFill, in: Capsule())
                Spacer(minLength: 0)
                Button(action: onOpen) {
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(Palette.mutedText)
                        .frame(width: 20, height: 20)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .help("Open on GitHub")
                Button(role: .destructive, action: onDelete) {
                    Image(systemName: "trash")
                        .font(.system(size: 11))
                        .foregroundStyle(hovering ? Color(hex: "C0453F") : Palette.mutedText)
                        .frame(width: 20, height: 20)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .help("Delete this repository on GitHub")
            }
        }
        .padding(12)
        .background(StudyPalette.cardFill, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous)
            .strokeBorder(isSelected ? Color(hex: "2DA44E") : (hovering ? StudyPalette.brown.opacity(0.5) : StudyPalette.line),
                          lineWidth: isSelected ? 1.8 : 1))
        .onHover { hovering = $0 }
        .contentShape(Rectangle())
    }
}

// MARK: - Connect card

private struct GitHubConnectCard: View {
    var onConnect: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "chevron.left.forwardslash.chevron.right")
                .font(.system(size: 26))
                .foregroundStyle(Palette.onAccent)
                .frame(width: 60, height: 60)
                .background(Color(hex: "24292F"), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            Text("Push to GitHub without the commands")
                .font(.mono(17, .bold))
            Text("Drop a file or a folder, pick a repo, press Push. LifeTracker commits it for you.")
                .font(.mono(12))
                .foregroundStyle(Palette.mutedText)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Button(action: onConnect) {
                Label("Connect GitHub", systemImage: "key.fill")
                    .frame(minWidth: 180)
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(hex: "24292F"))
        }
        .padding(30)
        .frame(maxWidth: 460)
        .background(Palette.elevated, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Palette.hairline))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Token sheet

private struct GitHubTokenSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @ObservedObject private var hub = GitHubSync.shared

    var onMessage: (String) -> Void

    @State private var token = ""
    @State private var busy = false
    @State private var error: String?

    private let newTokenURL = "https://github.com/settings/tokens/new?scopes=repo,delete_repo&description=LifeTracker"

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Connect GitHub").font(.mono(16, .bold))
            Text("LifeTracker uses a personal access token — the same thing the GitHub CLI uses. It's kept in this device's Keychain and never goes into an export file.")
                .font(.mono(11)).foregroundStyle(Palette.mutedText)
                .fixedSize(horizontal: false, vertical: true)

            VStack(alignment: .leading, spacing: 6) {
                Text("1 · Make a token").font(.mono(12, .semibold))
                Text("Open the link below. Tick **repo** (and **delete_repo** if you want the app to delete repositories), pick an expiry, then Generate.")
                    .font(.mono(11)).foregroundStyle(Palette.mutedText)
                    .fixedSize(horizontal: false, vertical: true)
                Button {
                    if let url = URL(string: newTokenURL) { openURL(url) }
                } label: {
                    Label("Open GitHub token page", systemImage: "arrow.up.right.square")
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Palette.callout, in: RoundedRectangle(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 6) {
                Text("2 · Paste it here").font(.mono(12, .semibold))
                HStack(spacing: 6) {
                    SecureField("ghp_…", text: $token)
                        .textFieldStyle(.roundedBorder)
                        .font(.mono(12))
                        #if os(iOS)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        #endif
                    Button("Paste") {
                        if let clip = Platform.pastedString() { token = clip.trimmingCharacters(in: .whitespacesAndNewlines) }
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
            }

            if let error {
                Text(error)
                    .font(.mono(11)).foregroundStyle(Color(hex: "C0453F"))
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack {
                if busy { ProgressView().controlSize(.small) }
                Spacer()
                Button("Cancel") { dismiss() }
                Button("Connect") { connect() }
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)
                    .disabled(token.isEmpty || busy)
            }
        }
        .padding(20)
        .sheetFrame(width: 500, height: 420)
    }

    private func connect() {
        busy = true
        error = nil
        Task { @MainActor in
            if await hub.connect(token: token) {
                onMessage("Connected as @\(hub.user?.login ?? "")")
                dismiss()
            } else {
                error = hub.lastError ?? "GitHub wouldn't accept that token."
            }
            busy = false
        }
    }
}

// MARK: - New repo sheet

private struct NewRepoSheet: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var hub = GitHubSync.shared

    var onCreated: (GitHubRepo) -> Void

    @State private var name = ""
    @State private var description = ""
    @State private var isPrivate = true
    @State private var addReadme = true
    @State private var busy = false
    @State private var error: String?

    private var slug: String { GitHubSync.slug(name) }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("New repository").font(.mono(16, .bold))

            VStack(alignment: .leading, spacing: 5) {
                FormTextField("Name", text: $name)
                if !name.isEmpty && slug != name {
                    Text("GitHub will call it “\(slug)”.")
                        .font(.mono(10)).foregroundStyle(Palette.mutedText)
                }
            }
            FormTextField("Description (optional)", text: $description)

            Toggle(isOn: $isPrivate) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Private").font(.mono(12, .medium))
                    Text("Only you can see it. Turn this off to make it public.")
                        .font(.mono(10)).foregroundStyle(Palette.mutedText)
                }
            }
            Toggle(isOn: $addReadme) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Start with a README").font(.mono(12, .medium))
                    Text("Gives the repo a first commit, so pushing files works immediately.")
                        .font(.mono(10)).foregroundStyle(Palette.mutedText)
                }
            }

            if let error {
                Text(error)
                    .font(.mono(11)).foregroundStyle(Color(hex: "C0453F"))
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack {
                if busy { ProgressView().controlSize(.small) }
                Spacer()
                Button("Cancel") { dismiss() }
                Button("Create") { create() }
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)
                    .disabled(slug.isEmpty || busy)
            }
        }
        .padding(20)
        .sheetFrame(width: 460, height: 380)
    }

    private func create() {
        busy = true
        error = nil
        Task { @MainActor in
            if let repo = await hub.createRepo(name: name, description: description,
                                               isPrivate: isPrivate, addReadme: addReadme) {
                onCreated(repo)
                dismiss()
            } else {
                error = hub.lastError ?? "Couldn't create that repository."
            }
            busy = false
        }
    }
}
