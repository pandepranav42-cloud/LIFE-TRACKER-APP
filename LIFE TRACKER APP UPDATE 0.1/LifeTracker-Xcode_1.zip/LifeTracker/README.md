# Life — a minimal life tracker

Two builds of the same app:

- `LifeTracker/` — native macOS SwiftUI app (SwiftData + Swift Charts)
- `life-tracker.html` — standalone web version, identical screens, localStorage persistence

Both use the same minimal aesthetic: near-white/near-black surfaces, hairline borders, one restrained ink accent.

## macOS app setup

1. In Xcode: **File → New → Project → macOS → App**
2. Product Name: `LifeTracker` · Interface: **SwiftUI** · Language: **Swift** · Storage: **SwiftData**
3. Delete the auto-generated `LifeTrackerApp.swift`, `ContentView.swift`, and any sample model files.
4. Drag the entire `LifeTracker/` folder from this bundle into the Xcode project navigator. Choose **Copy items if needed** and **Create groups**.
5. Build target: macOS 14 or later (SwiftData + `NavigationSplitView`).
6. Build & run (⌘R).

### File map

```
LifeTracker/
├── LifeTrackerApp.swift          # @main + ModelContainer
├── Models/
│   ├── Models.swift              # Habit, HabitCompletion, ScheduleItem, JournalEntry,
│   │                              # TimetableCategory, TimetableSlot, TimetableBlock, TimetableImageAsset
│   └── Quotes.swift              # QuoteBank — curated quote list + rotation helpers
├── Views/
│   ├── ContentView.swift         # NavigationSplitView + Sidebar
│   ├── TodayView.swift           # dashboard: auto-rotating quote, Now/Next, habits, timeline, 7-day strip
│   ├── HabitsView.swift
│   ├── ScheduleView.swift
│   ├── TimetableView.swift       # blank-grid timetable, category manager, image upload
│   ├── StudyView.swift           # Study space: subjects, syllabus, materials (PDF/PPT/Word), notes, weekly to-do, mood board
│   └── OtherViews.swift          # Calendar, Progress, Journal, Settings
└── Components/
    ├── DesignSystem.swift        # Palette, section headers, card modifier, Color(hex:)
    └── Components.swift          # ProgressRing, HabitRow, ScheduleRow, StatCard, EmptyState
```

### Habits page

Every habit row now has its own tick checkbox for **today** — no need to go to the Today dashboard just to check something off. Tapping the name/icon still opens the edit sheet; the checkbox and the "⋯" menu are separate tap targets so they don't fight each other.

### Calendar — mark important dates

Any day can now carry your own colored markers — exams, deadlines, anniversaries, whatever. Select a day, type a title, pick from 10 color swatches (same palette as Timetable categories), and add it. Marks show as small colored dots under the date in the grid, and can be renamed, recolored, or deleted from the day's detail panel.

### Timetable, how it works

The grid has two independent layers:

1. **Time slots** — the rows. Add one via "Add Time Slot" (just a start/end time). This is the "border" — it exists with zero content, purely to define the grid's structure.
2. **Categories** — your own labels + colors. No presets. Add/rename/recolor/delete anytime from "Categories". 10 muted color swatches to pick from.
3. **Blocks** — the content. Tap any cell (day × time slot) to fill it in, choosing a title and category.

If you'd rather not build the grid at all, **Upload Image** lets you drop in a photo of a timetable you already made (on paper, in another app, wherever) — it replaces the grid entirely until you remove it.

Nothing is pre-filled. First launch is a blank timetable.

### Journal

Each entry has an optional title plus the usual text/mood/energy. Every entry you've ever saved — not just the last handful — is listed below the editor as "Saved Entries," each showing its date and the exact time it was saved. Tap one to reopen and edit it.

## Web version

Just open `life-tracker.html` in any modern browser. First run seeds a few sample habits and a daily schedule so those screens aren't empty — the Timetable is deliberately left blank. Data lives in `localStorage` under the key `life-tracker-v1`. Settings → Data has Export / Import / Reset.

If you're updating from an earlier version of this file, old saved data is automatically migrated on first load — any previously-seeded demo timetable is cleared out (since categories changed shape), everything else (habits, schedule, journal) is preserved.

## Design notes

- **Palette**: one ink accent (`Color.primary` on Mac, `#111` / `#f5f5f5` in the web version). Everything else is neutral. Both Light and Dark supported via system.
- **Typography**: system font throughout. Section labels are tiny caps with tracking; numbers use `.monospacedDigit`.
- **Spacing**: 32px page padding, 24px between sections, hairline dividers (opacity 0.06–0.08).
- **Progress ring**: single stroke, animated, no gradient.
- **Completed habits**: filled black square with a check — no color coding, no red for misses (per spec).
- **Missed days in history strip**: hairline outline only. Neutral, not accusatory.

### Latest updates (this pass)

- **Today** reflects Calendar marks: events show as colored chips, "habit for this day" marks appear as tickable rows in the habits card — in the color you chose.
- **Habits** has a new "This Month" calendar-shaped grid above "Last 30 days".
- **Schedule** items each get their own color (a small swatch picker in the editor), shown as the row's left accent.
- **Timetable** now rejects an exact duplicate time slot (same start+end as an existing row) with an inline error — adjacent ranges are still fine.
- **Calendar**: "Important Dates" is at the top of the day panel; the grid shows Apple-Calendar-style colored name pills instead of dots; marks are either an **Event** (informational, no tick) or a **Habit for this day** (tickable, counts in Progress).
- **Progress**: the weekly bar chart now shows the raw count of habits completed each day (regular habits + completed calendar habit-marks), not a percentage.
- **Journal** is locked to today only — no picking past or future dates to write in — and each entry can have its own color.
- **Settings**: replaced Export/Import with a single "Reset all data" action; added a Developer section (name, email, Contact link, Copy Email).


### Progress — how the numbers are counted

All progress numbers (Today, Habits, Progress) come from one `ProgressEngine` in `Models.swift`, so they always agree:

- A habit only counts on days it was actually scheduled (frequency, start date and pause periods respected). Pausing no longer wipes past history.
- Ticks on unscheduled days never inflate a percentage.
- Calendar "habit" marks count as one-off items on their day.
- Today is still in progress: open items are not counted as misses until the day is over.
- Future days are never counted.

The Progress page has 7 days / 30 days / This month / 90 days ranges, a comparison with the previous period, perfect days, active days, a daily completion chart, a weekday pattern and per-habit rates. The streak system has been removed.

### Quotes

The quote on Today changes by itself every 30 minutes (`QuoteBank.rotationMinutes`), cycling through the whole list without repeats. There is no manual refresh button.

### Study

A cozy "study space" page (below Timetable in the sidebar):

- Cover banner (click-to-change on hover), avatar and editable title, and an affirmation: a new one each day, or write your own with the pencil button.
- **classes** — subject cards with syllabus progress and file count. Right-click to edit/delete.
- Mini calendar, overview stats, live clock and a reminders checklist.
- **Mood Board** — add your own images.

Open a subject for three tabs:

- **Syllabus** — topics/chapters with ticks and a progress bar. "Paste list" adds one topic per clipboard line.
- **Materials** — add PDF, PowerPoint, Word, Keynote, Pages, images… via **Add Files** or drag-and-drop. Click to Quick Look, double-click to open in its app, right-click to Save a Copy / Rename / Delete. Files are stored inside the app, so moving the originals doesn't break anything.
- **Delete** — every card has its own 🗑: files, links (with a copy button beside it), syllabus topics, reminders and mood-board pictures. Nothing is hidden behind a right-click or a hover any more, so it all works the same on iPad.
- Files specifically: the 🗑 sits next to Share. If that file is backed up to Drive you're asked which copy to remove: *Delete here and in Drive* (the Drive copy goes to Drive's Bin — recoverable there for 30 days) or *Delete here only*. Files that were never uploaded just ask once. Mood-board pictures take their Drive copy with them the same way.
- **Share** — every file card has a ↑ button that opens the system share sheet: AirDrop, WhatsApp, Messages, Mail, Telegram, Save to Files, anything installed. With more than one file in view, **Share All** sends the whole set in one go. The file is written out with its real name and extension at the moment you press share, so the person on the other end gets `Module-3.pdf`, not a copy of the database.
- **Notes** — free-form notes, saved automatically.

### Theme, light/dark and iPad

- The whole app now uses one warm "study space" theme (cream pages, latte cards, cocoa accent, monospaced headings). All colours live in `Palette` in `DesignSystem.swift`; each has a light and a dark value.
- Settings → Appearance: System / Light / Dark. "System" follows the Mac or iPad automatically.
- One target builds for **macOS 14+** and **iPadOS 17+**. In Xcode pick *My Mac* or any iPad simulator/device as the run destination.
- Every page reads the live width of the content area (`layoutWidth`), so layouts adapt to Mac window resizing and iPad full screen, Split View, Slide Over and Stage Manager.
- Mac-only features have iPad equivalents: files open in Quick Look (with Share / Save to Files) instead of an external app, and hover-only buttons are also available from press-and-hold menus.

### Progress: habits vs schedule tasks, with times

- Schedule items can now be ticked off on Today (round check on the right of each timeline row). Each tick stores the exact time.
- Habit ticks also store their time (older ticks from before this update show "—").
- **By weekday** shows, for each day, `habit N` and `schedule N` separately with two bars (cocoa = habits, blue = schedule tasks).
- **Daily completion**: click/tap any bar to see that day's log — every habit and schedule task with the time it was done.

### Calendar sync + accounts

- Calendar page → **Sync**: turn on Apple Calendar (EventKit). Marks you add/edit/delete are mirrored as all-day events into a "LifeTracker" calendar (or one you choose — including Google calendars added to System Settings → Internet Accounts). Your existing Apple Calendar events show on the LifeTracker calendar.
- Settings → **Accounts**: Sign in with Apple, and Sign in with Google (OAuth, Calendar scope). With Google signed in, turn on Google Calendar in the Sync sheet to write straight into your primary Google calendar.
- Setup needed once:
  - **Sign in with Apple**: Xcode → target → Signing & Capabilities → + Capability → Sign in with Apple (paid Apple Developer team required).
  - **Google**: create an OAuth client ID (type iOS, bundle id `com.pranavpande.LifeTracker`) in Google Cloud Console with the Calendar API enabled, then paste it in Settings → Accounts. Steps are shown in the app.
- Tokens are stored in the Keychain.

### Login, Drive backup, Google account

- The app opens on a **login screen** with two choices: **Continue with Google**, or **Continue as guest** right below it. (Apple login is hidden for now; the old developer username/password login is gone.)
- **Guest** opens the app immediately with no account. Everything works and stays on the device; Drive backup and Calendar sync are the only things that need Google, and connecting one later from Settings → Connected services keeps all existing data. Settings shows the session as "Signed in with Guest".
- Sign out from Settings → Account returns to the login screen.
- **Google Drive backup**: with Google connected, every study material, mood-board picture, Study cover and timetable image is uploaded to `LifeTracker/…` in your Drive (scope `drive.file`: the app only sees files it created). A ☁︎✓ badge shows on backed-up materials. Settings → Connected services has "Back up everything now".
- **One-time Google setup (developer)**: Google Cloud Console → new project → enable *Google Calendar API* and *Google Drive API* → OAuth consent screen (External, add your Gmail as test user) → Credentials → OAuth client ID, type **iOS**, bundle id `com.pranavpande.LifeTracker` → paste the client ID into `AppConfig.googleClientID` in `Models/Accounts.swift`.
- **Sign in with Apple**: Xcode → target → Signing & Capabilities → + Capability → Sign in with Apple (paid Apple Developer team).

### Google "G" logo

`GoogleG.png` (transparent, 192×192) is included in the project and shown on the "Continue with Google" button.

### Study → subject → Links

Each subject has a **Links** tab: paste ANY link — YouTube, Google Drive/Docs, Dropbox, GitHub, a PDF URL, a Notion page, mailto:, app links like notion:// or zoom://, intranet hosts, IP addresses or localhost:3000 — or drag one in from the browser. A pasted sentence containing a link works too. Titles are fetched automatically (YouTube via oEmbed, websites from the page title); YouTube links show the video thumbnail. Click to open; right-click / press-and-hold to copy, rename or delete.

### Study files: any type

Study → subject → **Files** accepts any file: PDF, slides, Word, spreadsheets, code (Python, C, C++, Java, JS/TS, Swift, SQL, … ~70 extensions recognised with a language badge and a code preview), images (with thumbnails), videos, audio, archives and anything else. Filter by type from the menu. Every file is backed up to Google Drive under `LifeTracker/Study/<Subject>/` when Google is connected.

### Journal lock
Journal → **Lock** (or Settings → Privacy). Every time you open the Journal it asks for Touch ID / Face ID or your device password; it re-locks when you leave the page or the app goes to the background. Turning the lock on or off also needs authentication. Journal text is hidden on the Calendar page while locked.

### Schedule notifications
Each schedule item has **Notify me** (at start, or 5/10/15/30/60 min before). Notifications repeat daily and are scheduled on each device — Mac and iPad — from the schedule stored there. Settings → Notifications turns them all on/off and shows permission status.

### Widgets (Mac + iPad)
A widget extension (`LifeTrackerWidgets` target) adds three widgets in small/medium/large: **Quote** (rotates every 30 min), **Timetable** (your uploaded timetable picture, or today's grid blocks), **Habits this month** (day-by-day heatmap + today's ring). They follow light/dark and the clear / tinted widget styles. The app feeds them through the App Group `group.com.pranavpande.LifeTracker`:
- Xcode → each target (LifeTracker and LifeTrackerWidgets) → Signing & Capabilities → pick your Team; Xcode registers the App Group automatically.
- Mac: right-click desktop → Edit Widgets. iPad: long-press home screen → Edit → Add Widget → LifeTracker.

### Export / Import (moving everything between Mac and iPad)

Settings → **Backup & transfer**:
- **Export everything** writes one `.lifetracker` file containing habits + ticks, schedule + ticks, timetable (grid *and* the uploaded picture), calendar marks, journal, study subjects with syllabus/notes/links and **every uploaded file** (PDF, slides, Word, code, images, video…), mood board, reminders and settings. Files are streamed one at a time, so large libraries don't blow up memory. On Mac you pick where to save; on iPad use Share / Save to Files (AirDrop, Drive, iCloud Drive…).
- **Import a backup** always **replaces everything**: this device is wiped and rebuilt from the file, so both devices end up identical. There's no merge option and nothing to choose — an export is a snapshot, and importing it restores that snapshot. Calendar events from the marks being replaced are pulled out of Apple/Google Calendar first, so nothing is orphaned there.
- Drive file ids travel with the export, so an imported device recognises files as already backed up and does not upload a second copy.

The two devices remain separate copies: changes made on one do not appear on the other until you export/import again.

### Calendar clean-up

Deleting a calendar mark now removes its event from Apple Calendar even when the stored event identifier has gone stale — every event LifeTracker writes carries a `LifeTracker-ID:` tag in its notes, and the delete falls back to finding it by that tag around the same day.

**Reset all data** and **Import** both sweep the calendars first: every tagged event within a ±3-year window goes, along with anything left in the LifeTracker calendar, and then that calendar itself is deleted if LifeTracker created it.

### Reset all data

Settings → Data → **Reset all data…** opens a full warning sheet rather than a one-line alert. It lists exactly what will go, counted item by item (habits, ticks, schedule, timetable blocks, calendar marks, journal entries, subjects, topics, files, links, mood-board pictures), and points you at Export first if you want a copy. The sheet itself is the confirmation — pressing **Erase everything** does it.

When a Google account is connected it also offers **Also delete the Google Drive backup**, on by default: every file LifeTracker uploaded *and* the whole `LifeTracker` folder are moved to Drive's Bin (restorable there for 30 days), so nothing is left behind — including files another device uploaded that this one never knew about. Drive is cleared first, while the file ids still exist, then the local database is wiped and the widgets refresh.

### GitHub — push without the commands

Study page → **GitHub** button, right beside JUNO.

Connect once with a GitHub **personal access token** (the sheet links straight to the pre-filled token page — tick `repo`, plus `delete_repo` if you want the app to delete repositories). The token lives in the device Keychain and never enters an export file.

After that it's three steps, every time:

1. **Drop** files or a whole folder onto the page (or click to pick them). Any file type. A folder keeps its shape — drop `Sem5/` and the repo gets `Sem5/…` exactly as it sits on disk. Dropped bytes are copied to a staging area immediately, because the sandbox permission from a drop expires before you press Push.
2. **Pick a repo** from the grid, or press **New repo** (name, description, private/public, optional README). The last repo you used is remembered.
3. **Push.** Optional folder prefix and commit message; leave both blank and each file gets a sensible message of its own.

Uploads go through GitHub's Contents API — one commit per file, exactly like the web "Upload files" button. A file that already exists is updated rather than rejected. GitHub's limit means anything over 50 MB is skipped and named in the result.

Below the picker, the selected repo's files are listed: tap a folder to go in, ↗ opens it on github.com, 🗑 deletes it with a commit (history keeps the old version). Each repo card has its own 🗑 to delete the whole repository — that one is permanent and needs the `delete_repo` scope.

### University portal (JUNO)

Study page → **JUNO** button (top right) opens your university ERP inside LifeTracker (`portal.homeURL`, default `https://erp.dypiu.ac.in/login.htm`). It's a real browser view with its own cookie store, so you stay logged in between launches. Toolbar: back / forward / reload / home, **Save page** (turns the current page — attendance, marks, result, fee receipt — into a PDF inside a subject's Files, and into Drive if connected), plus Open in browser, Copy link, Change portal address, and Sign out of portal (clears its cookies only).

Downloads inside the portal (the ⤓ buttons — module PPTs, PDFs, zips…) are captured by the app: a progress pill shows in the toolbar and when it finishes you pick the subject to file it into. Files land in that subject's **Files** tab (and Drive, if connected) without ever passing through your Downloads folder.

JUNO opens most of its documents through a pop-up window (`window.open` / `target="_blank"`). A web view with no window handler drops those clicks silently, so the portal view now answers them itself and loads the file in place; blob and data URLs the page builds in memory are read out of the page and handed to Swift as bytes. If a file still opens in the viewer rather than downloading — a PDF preview, usually — use **⋯ → Save the file on screen**, which refetches it with the portal's own cookies. **Save page** falls back to that automatically when the page is already a PDF.

**ID & Pass** (next to Save page) keeps as many portal logins as you like in the device Keychain — not in the database, and never written into a `.lifetracker` export. Each one has Fill, copy-ID and copy-password buttons, edit and delete.

You don't have to open that sheet to use them: **tap any sign-in box on the portal and a strip appears over the page** with your saved logins. One tap fills both boxes; the small copy button next to each name copies just the password for the odd field a page won't let anything type into. ✕ hides the strip until the next page.

LifeTracker does not read your marks or attendance automatically — JUNO has no student API, so numbers are not scraped.
